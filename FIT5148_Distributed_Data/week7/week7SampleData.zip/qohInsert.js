db.qoh.insertMany([
{ "_id" : 1, "type" : 2, "supplier" : "OFF", "qty" : 1000 },
{ "_id" : 2, "type" : 2, "supplier" : "OFF", "qty" : 500 },
{ "_id" : 3, "type" : 1, "supplier" : "ON", "qty" : 200 },
{ "_id" : 4, "type" : 3, "supplier" : "OFF", "qty" : 1000 },
{ "_id" : 5, "type" : 1, "supplier" : "ON", "qty" : 40 },
{ "_id" : 6, "type" : 2, "supplier" : "ON", "qty" : 1000 },
{ "_id" : 7, "type" : 3, "supplier" : "ON", "qty" : 5000 }
]
)
